# Dynamic-E-commerce-Website-with-recommendation-system
Project : Dynamic E-commerce Website with recommendation system

THIS IS MY THESIS PROJECT TO GET MY BACHELOR DEGREE  :


Dynamic E-commerce Website with recommendation system with php language for the backend and (HTML-CSS-Bootstrap-Jquery) for the front-end 

I try as much as I can to explain my source code with comments

in addition to that , I create a PDF rapport for my thesis , to explain all the technologies that I used in this project .

I use bootstrap to style all the <div> tags , JavaScript for  dynamic transactions .
PHP to manage the backend ; to get data from my local database and display it as a product ,reviews,etc...
MySQL for the database that I store my Project DataSets

Furthermore , I use recommendation system that recommends product for the user who is already signed in (User to user collaborative filtering). IN case of not signed user : I recommend the best selling for him .

ALWAYS REMEMBER : all this is explained with details in the PDf RAPPORT that I uploaded with the source code .  


there are also sreenshots in the rapport to see how the website looks like before you download it 

and a presentation if you want to present it in front of your teacher,classmate,jury,etc..




Leave a positive rate for me !

